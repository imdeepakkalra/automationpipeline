﻿// See https://aka.ms/new-console-template for more information
using System.Collections.Generic;
using System.Net;
using System.Text.RegularExpressions;

Console.WriteLine("Please select the command");
Console.WriteLine("1.File Copy");
Console.WriteLine("2.File Delete");
Console.WriteLine("3.Query Folder Files");
Console.WriteLine("4.Create Folder");
Console.WriteLine("5.Download File");
Console.WriteLine("6.Wait");
Console.WriteLine("7.Conditional Count Rows File");
Console.WriteLine("Please enter the input to execute command");
int choice = Convert.ToInt32(Console.ReadLine());
switch(choice)
{
    case 1:
        filecopy();
        break;
    case 2:
        filedelete();
        break;
    case 3:
        queryfolderfiles();
        break;
    case 4:
        createfolder();
            break;
    case 5:
        downloadfile();
        break;
    case 6:
        waitfunction();
        break;
    case 7:
        countrowsfile();
        break;
        
}

void filecopy()
{
    Console.WriteLine("Please enter the Source File"); 
    string sourceFile = Console.ReadLine();
    Console.WriteLine("Please enter the Destination File");
    string destinationFile = Console.ReadLine();
    try
    {
        File.Copy(sourceFile, destinationFile, true);
    }
    catch (IOException iox)
    {
        Console.WriteLine(iox.Message);
    }
}
void filedelete()
{ 
    try
   { 
      Console.WriteLine("Please enter the File Path");
      string rootFolder = Console.ReadLine();
      string[] files = Directory.GetFiles(rootFolder);
      foreach (string file in files)
      {
        File.Delete(file);
        Console.WriteLine($"{file} is deleted.");
      }
   }
   catch (Exception ex)
   {
    Console.WriteLine(ex.Message);
   }
}
void queryfolderfiles()
{
    try
    { 
    Console.WriteLine("Please enter the Folder Path");
    string rootFolder = Console.ReadLine();
    DirectoryInfo d = new DirectoryInfo(rootFolder);
    FileInfo[] Files = d.GetFiles();
    Console.WriteLine("Files in this directory.");
    Console.WriteLine("---------------------------------------------------------------------------------------");
    foreach (FileInfo file in Files)
    {
        Console.WriteLine("File Name : {0}", file.Name);
    }
    Console.ReadKey();
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}
void createfolder()
{
    try
    { 
    Console.WriteLine("Please enter the Folder Path");
    string rootFolder = Console.ReadLine();
    Console.WriteLine("Please enter the new Folder Name");
    string newFolder = Console.ReadLine();
    
    if (!Directory.Exists(rootFolder))
    {
        Directory.CreateDirectory(newFolder);
    }
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}

void downloadfile()
{
    try
    { 
    Console.WriteLine("Please enter the Source url");
    string remoteUri = Console.ReadLine();
    Console.WriteLine("Please enter the output File");
    string fileName = Console.ReadLine();

    
    string dest = @$"E:\{fileName}";                    // Local file

    using (WebClient webClient = new WebClient())
    {
        Console.WriteLine("Downloading file {0}...", fileName);

        // Download the Web resource and save it into the destination
        webClient.DownloadFile(remoteUri +fileName, dest);

        Console.WriteLine("Successfully downloaded file {0}", fileName);
    }
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}
void waitfunction()
{
    try
    { 
    Console.WriteLine("Please enter the wait time in seconds");
    
    int seconds =Convert.ToInt32(Console.ReadLine());
    int milliseconds = seconds * 1000;
    Thread.Sleep(milliseconds); 
    Console.WriteLine("...Program continues after "+  seconds+" seconds");
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}
void countrowsfile()
{
    try
    { 
    Console.WriteLine("Please enter the Source File");
    string sourceFile = Console.ReadLine();
    Console.WriteLine("Please enter the string to search in rows");
    string searchString = Console.ReadLine();


    var delim = " ,.".ToCharArray();
    var countWords = new[] { searchString };
    var wordPattern = new Regex(@"\b(?:" + String.Join("|", countWords) + @")\b", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    var count = File.ReadLines(sourceFile).Select(l => wordPattern.Matches(l).Count).Sum();
    Console.WriteLine("The rows count is {0}", count);
    }
    catch (Exception ex)
    {
        Console.WriteLine(ex.Message);
    }
}

